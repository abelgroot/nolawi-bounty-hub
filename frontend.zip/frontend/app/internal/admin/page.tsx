export default function Page() {
  return <div>Admin</div>;
}
